def finddensity():
    from urllib.request import urlopen
    from bs4 import BeautifulSoup
    URL1="https://en.wikipedia.org/wiki/Pythonidae"
    data=urlopen(URL1)
    soup=BeautifulSoup(data,'html.parser')
    newfeature= soup.find(id="content")
    newf=newfeature.text
    print(newf.strip())

    import re
    res = re.findall(r'[A-Z,a-z]+',newf)
    print("the total length of all the words in the content is:-",len(res))
    print("**************************************************")
   
    
    d={}
    density={}
    #removing  all duplicates in the content
    setofwords=set(res)
    #find all words frequency 
    listofwords=list(setofwords)
    print("the length of words after removal of duplicate words",len(listofwords))

    #find  density of the required words 
    findwords=['are','and','is']
    #print(len(listofwords))
    for word in findwords:
        counter=res.count(word)
        d[word]=counter
        density[word]=d[word]/len(res) * 100
        print('density of' ,word ,'is:-', density)
    print(d)
    print("*****************************************")
    #c=density[word]
    print(density)
          
    from matplotlib import pyplot
    #___________________________________________________________________
    x_axis=[]
    y_axis=[]

    for i,j in d.items():
       x_axis.append(i)
       y_axis.append(j)
    pyplot.bar(x_axis,y_axis)
    pyplot.show()

    from matplotlib import pyplot
    x_axis=[]
    y_axis=[]

    for i,j in density.items():
       x_axis.append(i)
       y_axis.append(j)
    pyplot.bar(x_axis,y_axis)
    pyplot.show()


    import sqlite3

    con=sqlite3.connect('webscraping6.db')

    con.execute("create table data(words text , occurance int , density  int)")
    #con.execute("insert into data values(word , counter , density ")
    print("data base created and inserted")
    con.commit()
    con.close
  

 #_____________________________________________________________________   

#creating a xlsx and soting the data
    from pyexcel  import save_as
    save_as(adict=d,dest_file_name='webscraping6.xlsx')
    print("xlsx created and data is stored succesfully")
#_______________________________________________________________________    
    

    
    

finddensity()


